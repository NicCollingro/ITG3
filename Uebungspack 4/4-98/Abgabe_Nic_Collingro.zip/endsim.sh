echo 999999 > system_soll.dat
